Blueberry Clothing Photo→Price App

Instructions:
1. Upload product images to `product_images/`
2. Update `products.csv` with product names and filenames
3. Run `compute_embeddings.py` to build FAISS index
4. Run `app.py` to start Flask server
5. Open browser to upload photos and get matches
6. Password for access: blueberry123