import os
import json
import csv
import numpy as np
from PIL import Image
from tqdm import tqdm
import torch
from transformers import CLIPProcessor, CLIPModel
import faiss

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
PRODUCT_IMAGES_DIR = os.path.join(BASE_DIR, 'product_images')
PRODUCTS_CSV = os.path.join(BASE_DIR, 'products.csv')
OUTPUT_META = os.path.join(BASE_DIR, 'products_meta.json')
OUTPUT_INDEX = os.path.join(BASE_DIR, 'faiss_index.bin')

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MODEL_NAME = "openai/clip-vit-base-patch32"

def load_products(csv_path):
    products = []
    with open(csv_path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    return products

def compute_embedding(model, processor, image_path):
    image = Image.open(image_path).convert("RGB")
    inputs = processor(images=image, return_tensors="pt")
    inputs = {k: v.to(DEVICE) for k, v in inputs.items()}
    with torch.no_grad():
        image_embeds = model.get_image_features(**inputs)
    emb = image_emb.cpu().numpy()[0]
    emb = emb / np.linalg.norm(emb)
    return emb.astype('float32')

def main():
    print("Device:", DEVICE)
    products = load_products(PRODUCTS_CSV)
    if not products:
        print("No products found in products.csv")
        return

    model = CLIPModel.from_pretrained(MODEL_NAME).to(DEVICE)
    processor = CLIPProcessor.from_pretrained(MODEL_NAME)

    embeddings = []
    meta = []
    for p in tqdm(products, desc="Products"):
        fname = p.get('filename')
        img_path = os.path.join(PRODUCT_IMAGES_DIR, fname)
        if not os.path.exists(img_path):
            print("Missing image for", fname, " — skipping")
            continue
        emb = compute_embedding(model, processor, img_path)
        embeddings.append(emb)
        meta.append(p)

    if not embeddings:
        print("No embeddings were computed.")
        return

    E = np.vstack(embeddings).astype('float32')
    d = E.shape[1]
    index = faiss.IndexFlatIP(d)
    index.add(E)
    faiss.write_index(index, OUTPUT_INDEX)
    print("Saved FAISS index to", OUTPUT_INDEX)

    with open(OUTPUT_META, 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print("Saved product metadata to", OUTPUT_META)
    print("Done. Indexed", len(meta), "products.")

if __name__ == "__main__":
    main()